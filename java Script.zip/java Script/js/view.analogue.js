"use strict";

const AnalogueView = {
    hourHand: document.getElementById("hour-hand"),
    minuteHand: document.getElementById("minute-hand"),
    secondHand: document.getElementById("second-hand"),

    render: function (time) {
        const secondDegrees = time.seconds * 6;
        const minuteDegrees = time.minutes * 6 + time.seconds * 0.1;
        const hourDegrees = (time.hours % 12) * 30 + time.minutes * 0.5;

        this.secondHand.style.transform = `translateX(-50%) rotate(${secondDegrees}deg)`;
        this.minuteHand.style.transform = `translateX(-50%) rotate(${minuteDegrees}deg)`;
        this.hourHand.style.transform = `translateX(-50%) rotate(${hourDegrees}deg)`;
    }
};