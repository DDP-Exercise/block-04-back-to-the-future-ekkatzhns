"use strict";

const TimeModel = {
    getCurrentTime: function () {
        const now = new Date();

        return {
            hours: now.getHours(),
            minutes: now.getMinutes(),
            seconds: now.getSeconds()
        };
    },

    formatTime: function (time) {
        const hours = String(time.hours).padStart(2, "0");
        const minutes = String(time.minutes).padStart(2, "0");
        const seconds = String(time.seconds).padStart(2, "0");

        return `${hours}:${minutes}:${seconds}`;
    },

    saveTime: function (time) {
        const formattedTime = this.formatTime(time);
        localStorage.setItem("savedTime", formattedTime);
    },

    getSavedTime: function () {
        return localStorage.getItem("savedTime");
    }
};