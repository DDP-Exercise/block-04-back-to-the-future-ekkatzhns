"use strict";

const DigitalView = {
    clockElement: document.getElementById("digital-clock"),

    render: function (time) {
        this.clockElement.textContent = TimeModel.formatTime(time);
    }
};