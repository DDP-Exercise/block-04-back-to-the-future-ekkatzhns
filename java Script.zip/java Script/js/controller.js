"use strict";

function updateClocks() {
    const currentTime = TimeModel.getCurrentTime();

    DigitalView.render(currentTime);
    AnalogueView.render(currentTime);
}

function showSavedTime() {
    const savedTimeElement = document.getElementById("saved-time");
    const savedTime = TimeModel.getSavedTime();

    if (savedTime) {
        savedTimeElement.textContent = savedTime;
    } else {
        savedTimeElement.textContent = "nothing saved yet";
    }
}

function saveCurrentTime() {
    const currentTime = TimeModel.getCurrentTime();

    TimeModel.saveTime(currentTime);
    showSavedTime();
    showFullscreenPhoto();
}

function showFullscreenPhoto() {
    const photo = document.getElementById("fullscreen-photo");

    photo.classList.add("show");

    setTimeout(function () {
        photo.classList.remove("show");
    }, 700);
}

document.getElementById("save-time").addEventListener("click", saveCurrentTime);

updateClocks();
showSavedTime();

setInterval(updateClocks, 1000);